import ServoControl
import time

if __name__ == '__main__': 
    while True:
        servos = [1, 2500, 2, 500]
        ServoControl.setPWMServoMoveByArray(servos, 2, 1000)
        time.sleep(2)
        servos = [1, 500, 2, 2500]
        ServoControl.setPWMServoMoveByArray(servos, 2, 1000)
        time.sleep(2)
    
