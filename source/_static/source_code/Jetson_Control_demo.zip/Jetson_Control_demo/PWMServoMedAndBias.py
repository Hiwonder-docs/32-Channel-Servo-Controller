import ServoControl
import time

if __name__ == '__main__': 
    deviation = 80
    ServoControl.setPWMServoMove(1, 1500, 800)
    time.sleep(2)
    ServoControl.setPWMServoMove(1, 1500+deviation, 800)
    while True:
        time.sleep(1)

    
