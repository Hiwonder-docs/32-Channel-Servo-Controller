#ifndef _TYPEDEF_H_
#define _TYPEDEF_H_

typedef bit				bool, BOOL;

typedef unsigned char	u8, U8, uint8, uint8_t, UINT8, BYTE;
typedef signed char		s8, S8, int8, INT8;

typedef unsigned short	u16, U16, uint16, uint16_t, UINT16, WORD;
typedef signed short	s16, S16, int16, INT16;

typedef unsigned long	u32, U32, uint32, UINT32, DWORD;
typedef signed long		s32, S32, int32, INT32;

typedef unsigned short	string;

#endif
