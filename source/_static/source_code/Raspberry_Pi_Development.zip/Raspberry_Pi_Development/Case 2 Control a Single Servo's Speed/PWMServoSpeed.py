import ServoControl
import time

if __name__ == '__main__': 
    while True:
        ServoControl.setPWMServoMove(1, 500, 1200)
        time.sleep(2)
        ServoControl.setPWMServoMove(1, 2500, 1200)
        time.sleep(2)
        ServoControl.setPWMServoMove(1, 500, 400)
        time.sleep(1)
        ServoControl.setPWMServoMove(1, 2500, 400)
        time.sleep(1)
    
